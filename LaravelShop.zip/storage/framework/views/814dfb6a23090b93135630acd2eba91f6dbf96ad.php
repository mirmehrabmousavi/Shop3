

<?php if($menu->menus->isEmpty()): ?>

    <?php switch($menu->type):
        case ('static'): ?>
            <?php echo $__env->make('front::partials.menu.static-menus', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ('category'): ?>

            <?php echo $__env->make('front::partials.menu.child-menucategory', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ('normal'): ?>
        <?php case ('megamenu'): ?>

            <li class="list-item">
                <a class="nav-link" href="<?php echo e($menu->link); ?>"><?php echo e($menu->title); ?></a>
            </li>

    <?php endswitch; ?>

<?php else: ?>

    <?php switch($menu->type):
        case ('category'): ?>

            <li class="list-item list-item-has-children menu-col-1">
                <a class="nav-link" href="<?php echo e($menu->category->link); ?>"><?php echo e($menu->category->title); ?></a>
                <ul class="sub-menu nav">
                    <?php if(!$menu->category->categories->isEmpty()): ?>
                        <?php $__currentLoopData = $menu->category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('front::partials.menu.child-category', ['category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php $__currentLoopData = $menu->childrenmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.menu.child-menu', ['menu' => $childMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <?php break; ?>

        <?php case ('megamenu'): ?>

            <?php echo $__env->make('front::partials.menu.megamenu', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php break; ?>

        <?php default: ?>

            <li class="list-item list-item-has-children menu-col-1">
                <a class="nav-link" href="<?php echo e($menu->link); ?>"><?php echo e($menu->title); ?></a>
                <ul class="sub-menu nav">
                    <?php $__currentLoopData = $menu->childrenmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.menu.child-menu', ['menu' => $childMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

    <?php endswitch; ?>

<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/menu/child-menu.blade.php ENDPATH**/ ?>