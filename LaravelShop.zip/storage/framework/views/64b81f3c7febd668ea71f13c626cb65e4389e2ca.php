<?php $__env->startSection('content'); ?>

    <!-- Start main-content -->
    <main class="main-content dt-sl mt-4 mb-3">
        <div class="container main-container">

            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 search-card-res">
                    <!-- Start Content -->
                    <div class="title-breadcrumb-special dt-sl mb-3">
                        <div class="breadcrumb dt-sl">
                            <nav>
                                <a href="/">خانه</a>
                                <a href="<?php echo e(route('front.products.index')); ?>">محصولات</a>
                                <span><?php echo e('جستجو برای ' . request('q')); ?></span>
                            </nav>
                        </div>
                    </div>
                    <?php if($products->count()): ?>
                        <div class="dt-sl dt-sn px-0 search-amazing-tab">
                            <div class="row mb-3 mx-0 px-res-0">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 px-10 mb-1 px-res-0">
                                        <?php echo $__env->make('front::products.partials.product-card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <?php echo e($products->appends(request()->all())->links('front::components.paginate')); ?>

                        </div>
                    <?php else: ?>
                        <?php echo $__env->make('front::partials.empty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
                <!-- End Content -->
            </div>

        </div>
    </main>
    <!-- End main-content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front::layouts.master', ['title' => 'جستجو برای ' . request('q')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/products/search.blade.php ENDPATH**/ ?>