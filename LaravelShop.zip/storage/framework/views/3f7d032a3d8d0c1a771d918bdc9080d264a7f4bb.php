<!-- Start footer -->
<footer class="main-footer dt-sl position-relative">
    <div class="back-to-top">
        <a href="#"><span class="icon"><i class="mdi mdi-chevron-up"></i></span> <span>بازگشت به
                بالا</span></a>
    </div>
    <div class="container main-container">


        <div class="footer-widgets">
            <div class="row">
                <?php $__currentLoopData = $footer_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="widget-menu widget card">
                            <header class="card-header">
                                <h3 class="card-title"><?php echo e(option('link_groups_' . $group['key'], $group['name'])); ?></h3>
                            </header>
                            <ul class="footer-menu">
                                <?php $__currentLoopData = $links->where('link_group_id', $group['key']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($link->link); ?>"><?php echo e($link->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12 col-md-6 col-lg-3">

                    <div class="symbol footer-logo">

                        <?php if(option('info_enamad')): ?>
                            <?php echo option('info_enamad'); ?>

                        <?php endif; ?>

                        <?php if(option('info_samandehi')): ?>
                            <?php echo option('info_samandehi'); ?>

                        <?php endif; ?>

                    </div>
                    <div class="socials">
                        <div class="footer-social">
                            <ul class="text-center">
                                <?php if(option('social_instagram')): ?>
                                    <li><a href="<?php echo e(option('social_instagram')); ?>"><i class="mdi mdi-instagram"></i></a></li>
                                <?php endif; ?>

                                <?php if(option('social_whatsapp')): ?>
                                    <li><a href="<?php echo e(option('social_whatsapp')); ?>"><i class="mdi mdi-whatsapp"></i></a></li>
                                <?php endif; ?>

                                <?php if(option('social_telegram')): ?>
                                    <li><a href="<?php echo e(option('social_telegram')); ?>"><i class="mdi mdi-telegram"></i></a></li>
                                <?php endif; ?>

                                <?php if(option('social_facebook')): ?>
                                    <li><a href="<?php echo e(option('social_facebook')); ?>"><i class="mdi mdi-facebook"></i></a></li>
                                <?php endif; ?>

                                <?php if(option('social_twitter')): ?>
                                    <li><a href="<?php echo e(option('social_twitter')); ?>"><i class="mdi mdi-twitter"></i></a></li>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="copyright">
        <div class="container main-container">
            <p class="text-center"><?php echo e(option('info_footer_text')); ?></p>
        </div>
    </div>
</footer>
<!-- End footer -->
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/footer.blade.php ENDPATH**/ ?>