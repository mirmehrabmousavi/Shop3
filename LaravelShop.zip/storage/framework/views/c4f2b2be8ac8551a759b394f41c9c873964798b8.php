<!-- BEGIN: Custom CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/custom-rtl.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/assets/css/style-rtl.css')); ?>?v=10">
<!-- END: Custom CSS-->

<!-- font css file -->
<?php if(user_option('theme_font', 'Vazir') == 'Vazir'): ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/assets/fonts/vazir/style.css')); ?>">
<?php else: ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/assets/fonts/iransansdn/style.css')); ?>">
<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/partials/global-css.blade.php ENDPATH**/ ?>