<?php switch($menu->static_type):
    case ('products'): ?>
        <?php if($productcats->count()): ?>
            <li class="list-item list-item-has-children position-static">
                <a class="nav-link" href="<?php echo e(route('front.products.index')); ?>"><?php echo e($menu->title); ?></a>

                <ul class="f-menu sub-menu nav">
                    <?php $__currentLoopData = $productcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e($loop->first ? 'active' : ''); ?>">
                            <a class="master-menu" href="<?php echo e($category->link); ?>"><?php echo e($category->title); ?></a>
                            <div class="megadrop row">
                                <?php if($category->getCategoriesCount()): ?>

                                    <?php $__currentLoopData = $category->getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($childCategory->link); ?>"><div class="h5"><?php echo e($childCategory->title); ?></div></a>

                                        <?php if($childCategory->getCategoriesCount()): ?>

                                            <?php $__currentLoopData = $childCategory->getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e($child2->link); ?>"><div class="h6"><?php echo e($child2->title); ?></div></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php break; ?>

    <?php case ('posts'): ?>
        <?php if($postcats->count()): ?>

            <!-- mega menu 5 column -->
            <li class="list-item list-item-has-children menu-col-1">
                <a class="nav-link" href="<?php echo e(route('front.posts.index')); ?>"><?php echo e($menu->title); ?></a>
                <ul class="sub-menu nav">
                    <?php $__currentLoopData = $postcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.menu.child-category', ['category' => $category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php break; ?>

<?php endswitch; ?>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/menu/static-menus.blade.php ENDPATH**/ ?>