
<?php if(!$category->getCategoriesCount()): ?>
    <li>
        <a href="<?php echo e($category->link); ?>"><?php echo e($category->title); ?></a>
    </li>
<?php else: ?>

    <li class="sub-menu">
        <a href="<?php echo e($category->link); ?>"><?php echo e($category->title); ?></a>
        <ul>
            <li>
                <a class="text-nowrap" href="<?php echo e($category->link); ?>"><i class="mdi mdi-chevron-left"></i>همه موارد این دسته</a>
            </li>

            <?php $__currentLoopData = $category->getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('front::partials.mobile-menu.child-category', ['category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/mobile-menu/child-category.blade.php ENDPATH**/ ?>