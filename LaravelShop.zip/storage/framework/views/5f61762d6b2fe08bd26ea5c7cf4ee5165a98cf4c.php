<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="rtl">
<!-- BEGIN: Head-->

<head>
    <?php echo $__env->make('back.partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo e($title); ?></title>

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/vendors/css/vendors-rtl.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/vendors/css/extensions/toastr.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/themes/dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/themes/semi-dark-layout.css')); ?>">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/core/colors/palette-gradient.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/plugins/extensions/toastr.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/pages/authentication.css')); ?>">
    <!-- END: Page CSS-->

    <?php echo $__env->make('back.partials.global-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern semi-dark-layout 1-column  navbar-floating footer-static bg-full-screen-image  blank-page blank-page" data-open="click" data-menu="vertical-menu-modern" data-col="1-column" data-layout="semi-dark-layout">
    <!-- BEGIN: Content-->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- END: Content-->


    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('back/app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('back/app-assets/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('back/app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('back/app-assets/js/core/app.js')); ?>"></script>
    <script src="<?php echo e(asset('back/app-assets/js/scripts/components.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('back/assets/js/scripts.js')); ?>?v=8"></script>
    <script src="<?php echo e(asset('back/app-assets/js/scripts/extensions/toastr.js')); ?>"></script>

    <script>
        var BASE_URL = "<?php echo e(route('admin.dashboard')); ?>";
        var FRONT_URL = "<?php echo e(Route::has('front.index') ? route('front.index') : url('/')); ?>";    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/auth/layouts/master.blade.php ENDPATH**/ ?>