<?php if(!config()->has('front.errors.404')): ?>
    <?php echo $__env->make('errors.404-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make(config('front.errors.404'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php /**PATH D:\Installed\www\LaravelShop\resources\views/errors/404.blade.php ENDPATH**/ ?>