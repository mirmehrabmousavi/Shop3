<?php if($menu->menus->isEmpty()): ?>

    <?php switch($menu->type):
        case ('static'): ?>
        <?php echo $__env->make('front::partials.mobile-menu.static-menus', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('category'): ?>

        <?php echo $__env->make('front::partials.mobile-menu.child-category', ['category' => $menu->category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php default: ?>

        <li>
            <a href="<?php echo e($menu->link); ?>"><?php echo e($menu->title); ?></a>
        </li>

    <?php endswitch; ?>
<?php else: ?>

    <?php switch($menu->type):
        case ('category'): ?>
        <li class="sub-menu">
            <a href="<?php echo e($menu->category->link); ?>"><?php echo e($menu->category->title); ?></a>
            <ul>

                <?php if($menu->category->getCategoriesCount()): ?>
                    <?php $__currentLoopData = $menu->category->getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.mobile-menu.child-category', ['category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php $__currentLoopData = $menu->childrenmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('front::partials.mobile-menu.child-menu', ['menu' => $childMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </li>

        <?php break; ?>

        <?php default: ?>

        <li class="sub-menu">
            <a href="<?php echo e($menu->link); ?>"><?php echo e($menu->title); ?></a>
            <ul>
                <?php $__currentLoopData = $menu->childrenmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('front::partials.mobile-menu.child-menu', ['menu' => $childMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>

    <?php endswitch; ?>
<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/mobile-menu/child-menu.blade.php ENDPATH**/ ?>