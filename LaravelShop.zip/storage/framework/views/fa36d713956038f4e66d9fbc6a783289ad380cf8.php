<?php $__env->startPush('styles'); ?>
    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('back/app-assets/plugins/nestable2/jquery.nestable.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/jquery-ui/jquery-ui.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb no-border">
                                    <li class="breadcrumb-item">مدیریت
                                    </li>
                                    <li class="breadcrumb-item active">مدیریت منوها
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                    <div class="form-group breadcrum-right">
                        <div id="save-changes" class="spinner-border text-success" role="status" style="display: none">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>

            </div>
            <div class="content-body">
                <!-- menus -->
                <section id="description" class="card">
                    <div class="card-header">
                        <h4 class="card-title">مدیریت منوها</h4>
                        <button class="btn btn-success" data-toggle="modal" data-target="#modal-add"><i class="fa fa-plus mr-1"></i> افزودن منوی جدید</button>
                    </div>
                    <div id="main-block" class="card-content">
                        <div class="card-body">
                            <!-- menus -->
                            <div class="col-12 offset-xl-2">

                                <!-- List menus -->
                                <div class="dd my-5">
                                    <ol class="dd-list">
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('back.menus.partials.child_menu', ['child_menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                </div>
                                <!-- END List menus -->
                                <p class="card-text mt-3"><i class="feather icon-info mr-1 align-middle"></i><span class="text-info">برای ایجاد زیر منو، منو مورد نظر را به  سمت چپ بکشید.</span></p>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade text-left" id="modal-add" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">ایجاد منوی جدید </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="create-menu" action="#">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>نوع منو</label>
                                    <select class="form-control" id="menu-type" name="type">
                                        <option value="normal">منوی معمولی</option>
                                        <option value="category">منوی دسته بندی </option>
                                        <option value="static">منوی ثابت </option>
                                        <option value="megamenu">مگامنو </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-12" id="menu-title-div">
                                <div class="form-group">
                                    <label>عنوان</label>
                                    <input type="text" class="form-control" name="title">
                                </div>
                            </div>
                            <div class="col-12" id="menu-link-div">
                                <div class="form-group">
                                    <label>لینک</label>
                                    <input type="text" class="form-control create-menu-link ltr" name="link">
                                </div>
                            </div>

                            <div class="col-12" id="menu-category-div" style="display: none;">
                                <div class="form-group">
                                    <label>عنوان</label>
                                    <input type="text" class="form-control" name="category_title">
                                    <p class="text-muted">این فیلد اختیاری است</p>
                                </div>

                                <div class="form-group">
                                    <label>انتخاب دسته بندی</label>
                                    <select class="form-control" id="category" name="category">

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categoryGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e(category_group($key)); ?>">
                                                <?php $__currentLoopData = $categoryGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->full_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <fieldset class="checkbox">
                                        <div class="vs-checkbox-con vs-checkbox-primary">
                                            <input type="checkbox" name="children" checked>
                                            <span class="vs-checkbox">
                                                <span class="vs-checkbox--check">
                                                    <i class="vs-icon feather icon-check"></i>
                                                </span>
                                            </span>
                                            <span class="">اضافه کردن زیر دسته ها</span>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>

                            <div class="col-12" id="menu-static-div" style="display: none;">
                                <div class="form-group">
                                    <label>انتخاب منو</label>
                                    <select class="form-control" id="static" name="static">
                                        <?php $__currentLoopData = config('general.static_menus'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $static_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($static_menu['title']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger waves-effect waves-light" data-dismiss="modal">انصراف</button>
                        <button type="submit" class="btn btn-success waves-effect waves-light">ذخیره</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- END Add Modal -->

    <!-- Delete Modal -->
    <div class="modal fade text-left" id="modal-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel19" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel19">آیا مطمئن هستید؟</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    با حذف این منو تمامی زیر منو های آن حذف خواهند شد، آیا برای حذف
                            مطمئن هستید؟
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success waves-effect waves-light" data-dismiss="modal">خیر</button>
                    <button id="confirm-delete" type="button" class="btn btn-danger waves-effect waves-light">بله حذف شود</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END Delete Modal -->

    <!-- Edit Modal -->
    <div class="modal fade text-left" id="modal-edit" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">ویرایش منو </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="edit-form" action="#">
                    <div class="modal-body">
                        <div class="row">
                            <?php echo method_field('put'); ?>
                            <div class="col-12 d-none">
                                <div class="form-group">
                                    <label>نوع منو</label>
                                    <select class="form-control" id="edit-menu-type" name="type">
                                        <option value="normal">منوی معمولی</option>
                                        <option value="category">منوی دسته بندی </option>
                                        <option value="static">منوی ثابت </option>
                                        <option value="megamenu">مگامنو </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-12" id="edit-menu-title-div">
                                <div class="form-group">
                                    <label>عنوان</label>
                                    <input type="text" class="form-control" name="title">
                                </div>
                            </div>
                            <div class="col-12 not-static" id="edit-menu-link-div">
                                <div class="form-group">
                                    <label>لینک</label>
                                    <input type="text" class="form-control edit-menu-link ltr" name="link">
                                </div>
                            </div>

                            <div class="col-12 not-static" id="edit-menu-category-div" style="display: none;">
                                <div class="form-group">
                                    <label>عنوان</label>
                                    <input type="text" class="form-control" name="category_title">
                                    <p class="text-muted">این فیلد اختیاری است</p>
                                </div>

                                <div class="form-group">
                                    <label>انتخاب دسته بندی</label>
                                    <select class="form-control" id="edit-category" name="category">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categoryGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e(category_group($key)); ?>">
                                                <?php $__currentLoopData = $categoryGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->full_title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <fieldset class="checkbox">
                                        <div class="vs-checkbox-con vs-checkbox-primary">
                                            <input type="checkbox" name="children" checked>
                                            <span class="vs-checkbox">
                                                <span class="vs-checkbox--check">
                                                    <i class="vs-icon feather icon-check"></i>
                                                </span>
                                            </span>
                                            <span class="">اضافه کردن زیر دسته ها</span>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>

                            <div class="col-12" id="edit-menu-static-div" style="display: none;">
                                <div class="form-group">
                                    <label>انتخاب منو</label>
                                    <select class="form-control" id="edit-static" name="static">
                                        <?php $__currentLoopData = config('general.static_menus'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $static_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($static_menu['title']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger waves-effect waves-light" data-dismiss="modal">انصراف</button>
                        <button type="submit" class="btn btn-success waves-effect waves-light">ذخیره</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- END Edit Modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('back/app-assets/plugins/nestable2/jquery.nestable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/app-assets/plugins/jquery-ui/jquery-ui.js')); ?>"></script>

    <!-- Page JS Code -->
    <script>
        var pages =  [
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                "/pages/<?php echo e($page); ?>",
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];

        var megaMenuDepth = <?php echo e(config('front.mega_menu_depth') ?: 3); ?>;
    </script>
    <script src="<?php echo e(asset('back/assets/js/pages/menus.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/menus/index.blade.php ENDPATH**/ ?>