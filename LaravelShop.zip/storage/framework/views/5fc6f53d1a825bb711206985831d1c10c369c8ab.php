<?php $__env->startSection('user-content'); ?>
    <!-- Start Content -->
    <div class="col-xl-9 col-lg-8 col-md-8 col-sm-12">
        <div class="row">
            <div class="col-lg-6">
                <div class="px-3">
                    <div class="section-title text-sm-title title-wide mb-1 no-after-title-wide dt-sl mb-2">
                        <h2>اطلاعات شخصی</h2>
                    </div>
                    <div class="profile-section dt-sl">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>نام:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->first_name); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>نام خانوادگی:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->last_name); ?></span>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>شماره تلفن همراه:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->username); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>ایمیل:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->email ?: '-'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>استان:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->address ? $user->address->province->name : '-'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>شهر:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->address ? $user->address->city->name : '-'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>کد پستی:</span>
                                </div>
                                <div class="value-info">
                                    <span><?php echo e($user->address ? $user->address->postal_code : '-'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="label-info">
                                    <span>آدرس کامل:</span>
                                </div>
                                <div class="value-info address">
                                    <span title="<?php echo e($user->address ? $user->address->address : '-'); ?>"><?php echo e($user->address ? ellips_text($user->address->address, 80) : '-'); ?></span>
                                </div>
                            </div>

                        </div>
                        <div class="profile-section-link">
                            <a href="<?php echo e(route('front.user.profile.edit')); ?>" class="border-bottom-dt">
                                <i class="mdi mdi-account-edit-outline"></i>
                                ویرایش اطلاعات شخصی
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-12">
                <div class="px-3">
                    <div
                        class="section-title text-sm-title title-wide mb-1 no-after-title-wide dt-sl mb-2">
                        <h2>لیست آخرین علاقه‌مندی‌ها</h2>
                    </div>
                    <div class="profile-section dt-sl">
                        <?php if($user->favorites()->count()): ?>
                            <ul class="list-favorites">
                                <?php $__currentLoopData = $user->favorites()->latest()->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.products.show', ['product' => $favorite->product])); ?>">
                                            <img data-src="<?php echo e($favorite->product->image ? asset($favorite->product->image) : asset('/no-image-product.png')); ?>" alt="">
                                            <span><?php echo e($favorite->product->title); ?></span>
                                        </a>
                                        <button data-action="<?php echo e(route('front.favorites.destroy', ['favorite' => $favorite])); ?>" data-toggle="modal" data-target="#favorite-delete-modal" class="favorite-remove-btn">
                                            <i class="mdi mdi-trash-can-outline"></i>
                                        </button>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="profile-section-link">
                                <a href="<?php echo e(route('front.favorites.index')); ?>" class="border-bottom-dt">
                                    <i class="mdi mdi-square-edit-outline"></i>
                                    مشاهده و ویرایش لیست مورد علاقه
                                </a>
                            </div>
                        <?php else: ?>
                            <p class="mt-2">چیزی برای نمایش وجود ندارد!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($last_orders->count()): ?>
                <div class="col-lg-12 mt-3">
                    <div class="section-title text-sm-title title-wide mb-1 no-after-title-wide dt-sl mb-2 px-res-1">
                        <h2>آخرین سفارش‌ها</h2>
                    </div>
                    <div class="dt-sl">
                        <div class="table-responsive">
                            <table class="table table-order">
                                <thead>
                                <tr>
                                    <td>#</td>
                                    <th>شماره سفارش</th>
                                    <th>تاریخ ثبت سفارش</th>
                                    <th>وضعیت پرداخت</th>
                                    <th>جزییات</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $last_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="text-info"><?php echo e($order->id); ?></td>
                                            <td><?php echo e(jdate($order->created_at)->format('%d %B %Y')); ?></td>
                                            <td>
                                                <?php if($order->status == 'paid'): ?>
                                                    <span class="text-success">پرداخت شده</span>
                                                <?php elseif($order->status == 'unpaid'): ?>
                                                    <span class="text-danger">پرداخت نشده</span>
                                                <?php else: ?>
                                                    <span class="text-danger">لغو شده</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="details-link">
                                                <a href="<?php echo e(route('front.orders.show', ['order' => $order])); ?>">
                                                    <i class="mdi mdi-chevron-left"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="link-to-orders" colspan="7"><a href="<?php echo e(route('front.orders.index')); ?>">مشاهده لیست سفارش ها</a></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>

    </div>
    <!-- End Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Start favorite delete -->
    <div class="modal fade" id="favorite-delete-modal" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="now-ui-icons location_pin"></i>
                        حذف از لیست علاقمندی ها
                    </h5>
                    <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <p>آیا تمایل به حذف این محصول از لیست علاقمندی ها دارید؟</p>

                            <div class="form-ui dt-sl">
                                <form id="favorite-remove-form" action="#" method="POST">
                                    <div class="modal-body text-center">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-md">بله حذف شود</button>
                                        <button class="btn btn-light" data-dismiss="modal">لغو</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End favorite delete -->

    <script src="<?php echo e(theme_asset('js/pages/favorites/index.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('front::user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/user/profile.blade.php ENDPATH**/ ?>