<?php if($child_menu->menus->isEmpty()): ?>
    <?php if($child_menu->type == 'static'): ?>
        <li data-category-type="<?php echo e($child_menu->type); ?>" class="dd-item dd-static" data-static="true" data-id="<?php echo e($child_menu->id); ?>">

            <div class="dd-handle"><span class="menu-title"><?php echo e($child_menu->full_title); ?></span>
                <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right delete-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-trash text-danger px-1"></i>حذف</a>
                <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right edit-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-pencil text-info px-1"></i>ویرایش</a>
            </div>
        </li>
    <?php else: ?>
        <li data-category-type="<?php echo e($child_menu->type); ?>" class="dd-item" data-id="<?php echo e($child_menu->id); ?>">

            <div class="dd-handle"><span class="menu-title"><?php echo e($child_menu->full_title); ?></span>
                <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right delete-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-trash text-danger px-1"></i>حذف</a>
                <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right edit-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-pencil text-info px-1"></i>ویرایش</a>
            </div>
        </li>
    <?php endif; ?>

<?php else: ?>
    <li data-category-type="<?php echo e($child_menu->type); ?>" class="dd-item" data-id="<?php echo e($child_menu->id); ?>">

        <div class="dd-handle"><span class="menu-title"><?php echo e($child_menu->full_title); ?></span>
            <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right delete-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-trash text-danger px-1"></i>حذف</a>
            <a data-menu="<?php echo e($child_menu->id); ?>" class="float-right edit-menu dd-nodrag" href="javascript:void(0)"><i class="fa fa-pencil text-info px-1"></i>ویرایش</a>
        </div>
        <ol class="dd-list">
            <?php $__currentLoopData = $child_menu->childrenMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('back.menus.partials.child_menu', ['child_menu' => $childMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </li>
<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/menus/partials/child_menu.blade.php ENDPATH**/ ?>