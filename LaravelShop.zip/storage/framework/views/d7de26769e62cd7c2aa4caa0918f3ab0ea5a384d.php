<?php $__env->startSection('content'); ?>
    <!-- Start main-content -->
    <main class="main-content dt-sl mt-4 mb-3">
        <div class="container main-container">

            <div class="row">
                <div class="col-12">
                    <div class="dt-sl dt-sn pt-3 pb-5">
                        <div class="error-page text-center">
                            <h1>صفحه‌ای که دنبال آن بودید پیدا نشد!</h1>
                            <a href="/" class="btn-primary-cm">برو به صفحه اصلی</a>
                            <img src="<?php echo e(theme_asset("img/theme/404.svg")); ?>" class="img-fluid" width="60%" alt="">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
    <!-- End main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front::layouts.master', ['title' => 'خطا صفحه یافت نشد'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/errors/404.blade.php ENDPATH**/ ?>