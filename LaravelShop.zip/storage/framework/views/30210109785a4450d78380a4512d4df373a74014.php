<!--start .author-author__info-->
<?php if(auth()->check()): ?>
    <ul class="nav float-left">
    <li class="nav-item account dropdown">
        <a class="nav-link" href="#" data-toggle="dropdown" aria-haspopup="true"
           aria-expanded="false">
            <span class="label-dropdown">حساب کاربری</span>
            <i class="mdi mdi-account-circle-outline"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-left">

            <?php if(auth()->user()->level == 'admin' || auth()->user()->level == 'creator'): ?>
                <a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">
                    پنل مدیریت
                </a>
            <?php endif; ?>
            <a class="dropdown-item" href="<?php echo e(route('front.user.profile')); ?>">
                <i class="mdi mdi-account-card-details-outline"></i>پروفایل
            </a>
            <a class="dropdown-item" href="<?php echo e(route('front.orders.index')); ?>">
                <i class="mdi mdi-account-edit-outline"></i>سفارشات من
            </a>
            <div class="dropdown-divider" role="presentation"></div>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                <i class="mdi mdi-logout-variant"></i>خروج
            </a>
        </div>
    </li>
</ul>
<?php else: ?>
    <ul class="nav float-left">
        <li class="nav-item account dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown" aria-haspopup="true"
               aria-expanded="false">
                <span class="label-dropdown">حساب کاربری</span>
                <i class="mdi mdi-account-circle-outline"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-sm dropdown-menu-left">
                <a class="dropdown-item" href="<?php echo e(route('login')); ?>">
                    <i class="mdi mdi-account-card-details-outline"></i>ورود به سایت
                </a>
                <a class="dropdown-item" href="<?php echo e(route('register')); ?>">
                    <i class="mdi mdi-account-edit-outline"></i>ثبت نام
                </a>
            </div>
        </li>
    </ul>
<?php endif; ?>


<!--end /.author-author__info--><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/user-menu.blade.php ENDPATH**/ ?>