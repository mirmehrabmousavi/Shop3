<?php if($links->where('link_group_id', $group['key'])->count()): ?>
    <section class="card links-sortable">
        <div class="card-header">
            <h4 class="card-title"><?php echo e(option('link_groups_' . $group['key'], $group['name'])); ?></h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead>
                            <tr>
                                <th class="text-center">ردیف</th>
                                <th>عنوان</th>
                                <th>لینک</th>
                                <th class="text-center">عملیات</th>
                            </tr>
                        </thead>
                        <tbody id="links-sortable-<?php echo e($loop->index); ?>">
                            <?php $__currentLoopData = $links->where('link_group_id', $group['key']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="link-<?php echo e($link->id); ?>">
                                    <td class="text-center draggable-handler">
                                        <div class="fonticon-wrap"><i class="feather icon-move"></i></div>
                                    </td>

                                    <td><?php echo e($link->title); ?></td>
                                    <td><?php echo e($link->link); ?></td>

                                    <td class="text-center">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('links.update')): ?>
                                            <a href="<?php echo e(route('admin.links.edit', ['link' => $link])); ?>" class="btn btn-info mr-1 waves-effect waves-light">ویرایش</a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('links.delete')): ?>
                                            <button type="button" data-link="<?php echo e($link->id); ?>" class="btn btn-danger mr-1 waves-effect waves-light btn-delete"  data-toggle="modal" data-target="#delete-modal">حذف</button>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

<?php else: ?>
    <section class="card links-sortable">
        <div class="card-header">
            <h4 class="card-title"><?php echo e($group['name']); ?></h4>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="card-text">
                    <p>چیزی برای نمایش وجود ندارد!</p>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/partials/links.blade.php ENDPATH**/ ?>