<div class="<?php echo e($setting['class'] ?? 'col-md-6 col-12'); ?>">
    <div class="form-group">
        <label><?php echo e($setting['title']); ?></label>
        <select class="form-control" name="settings[<?php echo e($setting['key']); ?>]" <?php echo $setting['attributes'] ?? ''; ?>>
            <?php $__currentLoopData = $setting['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $selected = option($setting['key']) == $item['value'];
                ?>

                <option value="<?php echo e($item['value']); ?>" <?php echo e($selected ? 'selected' : ''); ?>><?php echo e($item['title']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/themes/partials/select.blade.php ENDPATH**/ ?>