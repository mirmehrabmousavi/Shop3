<div class="item">
    <div class="product-card">
        <div class="product-head">
            <?php if($product->labels->count()): ?>
                <div class="row">
                    <div class="btn-group" role="group">
                        <?php $__currentLoopData = $product->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="fild_products">
                                <span><?php echo e($label->title); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="rating-stars">
                <i class="mdi mdi-star active"></i>
                <i class="mdi mdi-star active"></i>
                <i class="mdi mdi-star active"></i>
                <i class="mdi mdi-star active"></i>
                <i class="mdi mdi-star active"></i>
            </div>
            <?php if($product->discount): ?>
                <div class="discount">
                    <span><?php echo e($product->discount); ?> %</span>
                </div>
            <?php endif; ?>

        </div>
        <a class="product-thumb" href="<?php echo e(route('front.products.show', ['product' => $product])); ?>">
            <img data-src="<?php echo e($product->image ? asset($product->image) : asset('/no-image-product.png')); ?>" src="<?php echo e(theme_asset('images/600-600.png')); ?>" alt="<?php echo e($product->title); ?>">
        </a>
        <div class="product-card-body">

            <h5 class="product-title">
                <a href="<?php echo e(route('front.products.show', ['product' => $product])); ?>"><?php echo e($product->title); ?></a>
            </h5>
            <a class="product-meta" href="<?php echo e($product->category ? $product->category->link : '#'); ?>"><?php echo e($product->category ? $product->category->title : 'بدون دسته بندی'); ?></a>
            <div class="price-index-h">
                <div class="product-prices-div">
                    <span class="product-price"><?php echo e($product->getLowestPrice()); ?></span>

                    <?php if($product->getLowestDiscount()): ?>
                        <del class="product-price-del"><?php echo e($product->getLowestDiscount()); ?></del>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($product->isSinglePrice()): ?>
                <div class="cart">
                    <a data-action="<?php echo e(route('front.cart.store', ['product' => $product])); ?>" class="d-flex align-items-center add-to-cart-single" href="javascript:void(0)"><i class="mdi mdi-plus px-2"></i>
                        <span>افزودن به سبد</span>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/product-block.blade.php ENDPATH**/ ?>