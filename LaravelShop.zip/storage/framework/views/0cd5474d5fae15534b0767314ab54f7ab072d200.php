<nav class="main-menu dt-sl">
    <ul class="list float-right hidden-md">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('front::partials.menu.child-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
    <ul class="nav float-left">
        <?php echo $__env->make('front::partials.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>

    <?php echo $__env->make('front::partials.mobile-menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/menu/menu.blade.php ENDPATH**/ ?>