<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb no-border">
                                    <li class="breadcrumb-item">مدیریت
                                    </li>
                                    <li class="breadcrumb-item">تنظیمات
                                    </li>
                                    <li class="breadcrumb-item active">تنظیمات کلی
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- users edit start -->
                <section class="users-edit">
                    <div class="card">
                        <div id="main-card" class="card-content">
                            <div class="card-body">

                                <div class="tab-content">

                                    <form id="information-form" action="<?php echo e(route('admin.settings.information')); ?>" method="POST">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>عنوان وبسایت</label>
                                                        <input type="text" name="info_site_title" class="form-control" value="<?php echo e(option('info_site_title')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label for="basicInputFile">آیکون</label>
                                                    <div class="custom-file">
                                                        <input type="file" accept="image/*" name="info_icon" class="custom-file-input">
                                                        <label class="custom-file-label" for="inputGroupFile01"><?php echo e(option('info_icon')); ?></label>
                                                        <p><small>بهترین اندازه <span class="text-danger"><?php echo e(config('front.imageSizes.icon')); ?></span> پیکسل میباشد.</small></p>

                                                    </div>
                                                </fieldset>

                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label for="basicInputFile">لوگوی شرکت</label>
                                                    <div class="custom-file">
                                                        <input type="file" accept="image/*" name="info_logo" class="custom-file-input">
                                                        <label class="custom-file-label" for="inputGroupFile01"><?php echo e(option('info_logo')); ?></label>
                                                        <p><small>بهترین اندازه <span class="text-danger"><?php echo e(config('front.imageSizes.logo')); ?></span> پیکسل میباشد.</small></p>
                                                    </div>
                                                </fieldset>


                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>تلفن</label>
                                                        <input type="text" name="info_tel" class="form-control" value="<?php echo e(option('info_tel')); ?>" >
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>فکس</label>
                                                        <input type="text" name="info_fax" class="form-control" value="<?php echo e(option('info_fax')); ?>">
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>کد پستی</label>
                                                        <input type="text" name="info_postal_code" class="form-control" value="<?php echo e(option('info_postal_code')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>استان</label>
                                                    <select id="province"  name="info_province_id" class="form-control">
                                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($province->id); ?>" <?php if($province->id == option('info_province_id')): ?> selected <?php endif; ?>><?php echo e($province->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div id="city-div" class="form-group">
                                                    <label>شهر</label>
                                                    <select id="city" name="info_city_id" class="form-control">
                                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($city->id); ?>" <?php if($city->id == option('info_city_id')): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>کلمات کلیدی</label>
                                                    <input id="tags" type="text" name="info_tags" class="form-control" value="<?php echo e(option('info_tags')); ?>">
                                                </fieldset>

                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>توضیحات کوتاه</label>
                                                    <textarea name="info_short_description" class="form-control" rows="3"><?php echo e(option('info_short_description')); ?></textarea>
                                                </fieldset>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>اسکریپت نماد</label>
                                                    <textarea name="info_enamad" class="form-control ltr" rows="3"><?php echo e(option('info_enamad')); ?></textarea>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>کد ساماندهی</label>
                                                    <textarea name="info_samandehi" class="form-control ltr" rows="3"><?php echo e(option('info_samandehi')); ?></textarea>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>آدرس</label>
                                                    <textarea  name="info_address" class="form-control" rows="3"><?php echo e(option('info_address')); ?></textarea>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>متن فوتر</label>
                                                    <textarea  name="info_footer_text" class="form-control" rows="3"><?php echo e(option('info_footer_text')); ?></textarea>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-6">
                                                <fieldset class="form-group">
                                                    <label>اسکریپت های اضافه</label>
                                                    <textarea  name="info_scripts" class="form-control ltr" rows="3"><?php echo e(option('info_scripts')); ?></textarea>
                                                </fieldset>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>ایمیل</label>
                                                        <input type="text" name="info_email" class="form-control" value="<?php echo e(option('info_email')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>پیشوند آدرس ورود به بخش مدیریت سایت</label>
                                                        <input type="text" name="admin_route_prefix" class="form-control" value="<?php echo e(config('general.admin_route_prefix')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <dir class="row p-0">
                                            <div class="col-12">
                                                <h5>نقشه در صفحه تماس با ما</h5>
                                                <hr>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>طول جغرافیایی</label>
                                                        <input type="number" step="any" id="Longitude" name="info_Longitude" class="form-control" value="<?php echo e(option('info_Longitude', '46.28582686185837')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label>عرض جغرافیایی</label>
                                                        <input type="number" step="any" id="latitude" name="info_latitude" class="form-control" value="<?php echo e(option('info_latitude', '38.07709880960678')); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input info_map_type" id="info_map_type_google" name="info_map_type" value="google" <?php echo e(option('info_map_type') == 'google' ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label" for="info_map_type_google">نقشه گوگل</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input info_map_type" id="info_map_type_mapir" name="info_map_type" value="mapir" <?php echo e(option('info_map_type') == 'mapir' ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label" for="info_map_type_mapir">نقشه map.ir</label>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="map" id="googleMap"></div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="map" id="mapIr"></div>
                                            </div>

                                            <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1">
                                                <button type="submit" class="btn btn-primary glow">ذخیره تغییرات</button>

                                            </div>
                                        </dir>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- users edit ends -->

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.partials.plugins', ['plugins' => ['jquery-tagsinput', 'jquery.validate', 'mapp', 'google-map']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var info_latitude = "<?php echo e(option('info_latitude', '38.07709880960678')); ?>";
        var info_Longitude = "<?php echo e(option('info_Longitude', '46.28582686185837')); ?>";

        var mapIrApiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjYwMTBjYWE1OWU4ZDAyYzM0YWI2MGFhZDE5MTBhNjM5ZTZkYTI0MzA1ZmMwNzQzY2NmMjRkZmQ2Y2FlMzFjOThmODg4MjExYWY4ZDkwMGE1In0.eyJhdWQiOiIxMjcxOSIsImp0aSI6IjYwMTBjYWE1OWU4ZDAyYzM0YWI2MGFhZDE5MTBhNjM5ZTZkYTI0MzA1ZmMwNzQzY2NmMjRkZmQ2Y2FlMzFjOThmODg4MjExYWY4ZDkwMGE1IiwiaWF0IjoxNjEyODY3Mjc2LCJuYmYiOjE2MTI4NjcyNzYsImV4cCI6MTYxNTM3Mjg3Niwic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.QNujb2BIyM8mIMy2AhivkMTpVCRyanpUIifJguxoEe4hXB1MESD2CWnO0WPq854Bi6yQyfD2w-oqjOi5N1aZmX4prggmrYelHy_mC1JEwAhWien_6QviFAvkhGDC-aPW4zjFKG2REUkQzXaeL2em543P6-hWdjFaUVSibm1XL4_CUnjJiafQsMQ67ZJ5E7Cpk92L89nJ0LMaBocex56tRqz7_7wZQUAtDYjfal90h2XaGh3QZ2rMwl69ZfMTrOEeTM9O6YCynT3IoTpDnNSXExJeMDuGv4zCD37UYG1gpVtNfipwgvc2J_LzLMXS4rnVAV2ednLKEYu7-jUXr68psg';
    </script>

    <script src="<?php echo e(asset('back/assets/js/pages/settings/information.js')); ?>"></script>
    <script src="<?php echo e(asset('back/app-assets/js/scripts/navs/navs.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/settings/information.blade.php ENDPATH**/ ?>