<li class="dropdown dropdown-notification nav-item"><a class="nav-link nav-link-label" href="#"
        data-toggle="dropdown"><i class="ficon feather icon-bell"></i><span
            class="badge badge-pill badge-primary badge-up"><?php echo e($notifications->count() ?: ''); ?></span></a>
    <ul class="dropdown-menu dropdown-menu-media dropdown-menu-right">
        <li class="dropdown-menu-header">
            <div class="dropdown-header m-0 p-2">
                <h4 class="white"><?php echo e($notifications->count()); ?> اعلان جدید</h4>
            </div>
        </li>
        <li class="scrollable-container media-list">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($notification->type == 'OrderPaid'): ?>

                    <a class="d-flex justify-content-between" href="<?php echo e(route('admin.notifications')); ?>">
                        <div class="media d-flex align-items-start">
                            <div class="media-left"><i class="feather icon-plus-square font-medium-5 primary"></i></div>
                            <div class="media-body">
                                <h6 class="primary media-heading">سفارش جدید ثبت شد</h6><small
                                    class="notification-text"><?php echo e($notification->data['message']); ?></small>
                            </div><small>
                                <time class="media-meta"><?php echo e(jdate($notification->created_at)->ago()); ?></time></small>
                        </div>
                    </a>

                <?php elseif($notification->type == 'UserRegistered'): ?>
                    <a class="d-flex justify-content-between" href="<?php echo e(route('admin.notifications')); ?>">
                        <div class="media d-flex align-items-start">
                            <div class="media-left"><i class="feather icon-user font-medium-5 success"></i></div>
                            <div class="media-body">
                                <h6 class="success media-heading">کاربر جدید ثبت نام کرد</h6><small
                                    class="notification-text"><?php echo e($notification->data['message']); ?></small>
                            </div><small>
                                <time class="media-meta"><?php echo e(jdate($notification->created_at)->ago()); ?></time></small>
                        </div>
                    </a>

                <?php elseif($notification->type == 'ContactCreated'): ?>
                    <a class="d-flex justify-content-between" href="<?php echo e(route('admin.notifications')); ?>">
                        <div class="media d-flex align-items-start">
                            <div class="media-left"><i class="feather icon-message-square font-medium-5 info"></i></div>
                            <div class="media-body">
                                <h6 class="info media-heading">پیام جدید دریافت شد</h6><small
                                    class="notification-text"><?php echo e($notification->data['message']); ?></small>
                            </div><small>
                                <time class="media-meta"><?php echo e(jdate($notification->created_at)->ago()); ?></time></small>
                        </div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </li>
        <li class="dropdown-menu-footer">
            <a class="dropdown-item p-1 text-center" href="<?php echo e(route('admin.notifications')); ?>">نمایش همه اعلان ها</a>
        </li>
    </ul>
</li>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/partials/notifications.blade.php ENDPATH**/ ?>