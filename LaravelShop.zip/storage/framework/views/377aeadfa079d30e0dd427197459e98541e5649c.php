

<?php $__currentLoopData = $plugins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php switch($plugin):
        case ('ckeditor'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/ckeditor/ckeditor.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('jquery-tagsinput'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-tagsinput/jquery.tagsinput.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/jquery-tagsinput/jquery.tagsinput.min.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('jquery-tagsinput'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-tagsinput/jquery.tagsinput.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/jquery-tagsinput/jquery.tagsinput.min.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('datatable'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/datatable/scripts.bundle.js')); ?>"></script>
                <script src="<?php echo e(asset('back/app-assets/plugins/datatable/core.datatable.js')); ?>"></script>
                <script src="<?php echo e(asset('back/app-assets/plugins/datatable/datatable.checkbox.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/datatable/datatable.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('jquery-ui'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-ui/jquery-ui.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/jquery-ui/jquery-ui.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('dropzone'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/vendors/js/extensions/dropzone.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/vendors/css/file-uploaders/dropzone.min.css')); ?>">
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/css-rtl/plugins/file-uploaders/dropzone.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('jquery-ui-sortable'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-ui-sortable/jquery-ui.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('persian-datepicker'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/persian-date/persian-date.min.js')); ?>"></script>
                <script src="<?php echo e(asset('back/app-assets/plugins/persian-date/persian-datepicker.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/app-assets/plugins/persian-date/persian-datepicker.min.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('mapp'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script type="text/javascript" src="<?php echo e(asset('back/app-assets/mapp/js/mapp.env.js')); ?>"></script>
                <script type="text/javascript" src="<?php echo e(asset('back/app-assets/mapp/js/mapp.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" href="<?php echo e(asset('back/app-assets/mapp/css/mapp.min.css')); ?>">
                <link rel="stylesheet" href="<?php echo e(asset('back/app-assets/mapp/css/fa/style.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('apexcharts'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/vendors/js/charts/apexcharts.min.js')); ?>?v=2"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" href="<?php echo e(asset('back/app-assets/vendors/js/charts/apexcharts.css')); ?>">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('combo-tree'): ?>

            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/combo-tree/combo-tree.js')); ?>?v=1"></script>
            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('styles'); ?>
                <link rel="stylesheet" href="<?php echo e(asset('back/app-assets/plugins/combo-tree/combo-tree.css')); ?>?v=1">
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('google-map'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDdbCAXvJIl7CKZwfpTswAIHvqJmZTUPwQ"></script>
            <?php $__env->stopPush(); ?>

        <?php break; ?>

        <?php case ('jquery.validate'): ?>
            <?php $__env->startPush('scripts'); ?>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
                <script src="<?php echo e(asset('back/app-assets/plugins/jquery-validation/localization/messages_fa.min.js')); ?>"></script>
            <?php $__env->stopPush(); ?>

        <?php break; ?>

    <?php endswitch; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/partials/plugins.blade.php ENDPATH**/ ?>