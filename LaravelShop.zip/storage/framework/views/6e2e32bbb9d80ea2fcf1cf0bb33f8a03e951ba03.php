<?php if($paginator->hasPages()): ?>
    <div class="row">
        <div class="col-lg-12">
            <!-- Start Pagination -->
                <div class="pagination">
                    
                    <?php if(!$paginator->onFirstPage()): ?>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="prev"><i class="mdi mdi-chevron-double-right"></i></a>

                    <?php endif; ?>
                    
                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <a href="javascript:void(0)"><?php echo e($element); ?></a>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <a href="javascript:void(0)" class="active-page"><?php echo e($page); ?></a>
                                <?php else: ?>
                                    <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next"><i class="mdi mdi-chevron-double-left"></i></a>
                    <?php endif; ?>
                    
                </div>
            </nav>
            <!-- Ends: /pagination-default -->
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/components/paginate.blade.php ENDPATH**/ ?>