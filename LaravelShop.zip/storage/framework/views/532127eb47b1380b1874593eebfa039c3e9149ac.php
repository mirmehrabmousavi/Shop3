<?php $__env->startSection('user-content'); ?>
    <!-- Start Content -->
    <div class="col-xl-9 col-lg-8 col-md-8 col-sm-12">

        <?php if($orders->count()): ?>

            <div class="row">
                <div class="col-12">
                    <div
                            class="section-title text-sm-title title-wide mb-1 no-after-title-wide dt-sl mb-2 px-res-1">
                        <h2>همه سفارش‌ها</h2>
                    </div>
                    <div class="dt-sl">
                        <div class="table-responsive">
                            <table class="table table-order">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>شماره سفارش</th>
                                    <th>تاریخ ثبت سفارش</th>
                                    <th>مبلغ کل</th>
                                    <th>وضعیت پرداخت</th>
                                    <th>جزییات</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="text-info"><?php echo e($order->id); ?></td>
                                            <td><?php echo e(jdate($order->created_at)->format('%d %B %Y')); ?></td>
                                            <td><?php echo e(number_format($order->price)); ?> تومان</td>
                                            <td>
                                                <?php if($order->status == 'paid'): ?>
                                                    <span class="text-success">پرداخت شده</span>
                                                <?php elseif($order->status == 'unpaid'): ?>
                                                    <span class="text-danger">پرداخت نشده</span>
                                                <?php else: ?>
                                                    <span class="text-danger">لغو شده</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="details-link">
                                                <a href="<?php echo e(route('front.orders.show', ['order' => $order])); ?>">
                                                    <i class="mdi mdi-chevron-left"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <div class="page dt-sl dt-sn pt-3">
                        <p>چیزی برای نمایش وجود ندارد</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="mt-3">
            <?php echo e($orders->links('front::components.paginate')); ?>

        </div>

    </div>
    <!-- End Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front::user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/user/orders/index.blade.php ENDPATH**/ ?>