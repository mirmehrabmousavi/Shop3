<?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e(option('info_short_description')); ?>">
    <meta name="keywords" content="<?php echo e(option('info_tags')); ?>">

    <link rel="canonical" href="<?php echo e(url('/')); ?>" />
    
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "url": "<?php echo e(route('front.index')); ?>",
            "name": "<?php echo e(option('site_title')); ?>",
            "logo": "<?php echo e(option('info_logo') ? asset(option('info_logo')) : asset(config('front.asset_path') . 'img/logo.png')); ?>",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "<?php echo e(route('front.products.search')); ?>/?q={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Start main-content -->
    <main class="main-content dt-sl mt-4 mb-3">
        <div class="container main-container">
            <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php switch($widget->key):
                    case ('main-slider'): ?>
                        <?php echo $__env->make('front::widgets.main-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('products-default-block'): ?>
                        <?php echo $__env->make('front::widgets.products-default-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('products-colorful-block'): ?>
                        <?php echo $__env->make('front::widgets.products-colorful-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('middle-banners'): ?>
                        <?php echo $__env->make('front::widgets.middle-banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('coworker-sliders'): ?>
                        <?php echo $__env->make('front::widgets.coworker-sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('sevices-sliders'): ?>
                        <?php echo $__env->make('front::widgets.sevices-sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('categories'): ?>
                        <?php echo $__env->make('front::widgets.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>

                    <?php case ('posts'): ?>
                        <?php echo $__env->make('front::widgets.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php break; ?>
                <?php endswitch; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </main>
    <!-- End main-content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/index.blade.php ENDPATH**/ ?>