<button class="btn-menu">
    <div class="align align__justify">
        <span></span>
        <span></span>
        <span></span>
    </div>
</button>
<div class="side-menu">
    <div class="logo-nav-res dt-sl text-center">
        <a href="#">
            <img data-src="<?php echo e(option('info_logo', theme_asset('img/logo.png'))); ?>" alt="<?php echo e(option('info_site_title', 'لاراول شاپ')); ?>">
        </a>
    </div>
    <div class="search-box-side-menu dt-sl text-center mt-2 mb-3">
        <form action="<?php echo e(route('front.products.search')); ?>" method="GET">
            <input type="text" name="q" placeholder="جستجو کنید...">
            <i class="mdi mdi-magnify"></i>
        </form>
    </div>
    <ul class="navbar-nav dt-sl">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('front::partials.mobile-menu.child-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<div class="overlay-side-menu"></div>
<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/mobile-menu/menu.blade.php ENDPATH**/ ?>