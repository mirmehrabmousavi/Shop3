<footer class="footer footer-static footer-light">
</footer>
