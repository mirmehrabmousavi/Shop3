<?php switch($menu->static_type):
    case ('products'): ?>
        <?php if($productcats->count()): ?>
            <li class="sub-menu">
                <a href="<?php echo e(route('front.products.index')); ?>"><?php echo e($menu->title); ?></a>
                <ul>
                    <?php $__currentLoopData = $productcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.mobile-menu.child-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endif; ?>
        
        <?php break; ?>
        
    <?php case ('posts'): ?>
        <?php if($postcats->count()): ?>
            <li class="sub-menu">
                <a href="<?php echo e(route('front.posts.index')); ?>"><?php echo e($menu->title); ?></a>
                <ul>
                    <?php $__currentLoopData = $postcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('front::partials.mobile-menu.child-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endif; ?>
        
        <?php break; ?>

<?php endswitch; ?>

<?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/mobile-menu/static-menus.blade.php ENDPATH**/ ?>