<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb no-border">
                                    <li class="breadcrumb-item">مدیریت
                                    </li>
                                    <li class="breadcrumb-item">مدیریت صفحات
                                    </li>
                                    <li class="breadcrumb-item active">لیست صفحات
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">

                <?php if($pages->count()): ?>
                    <section class="card">
                        <div class="card-header">
                            <h4 class="card-title">لیست صفحات</h4>
                        </div>
                        <div class="card-content" id="main-card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>عنوان</th>
                                                <th class="text-center">لینک</th>
                                                <th class="text-center">وضعیت</th>
                                                <th class="text-center">عملیات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="page-<?php echo e($page->id); ?>-tr">

                                                    <td>
                                                        <div class="d-flex">
                                                            <?php echo e($page->title); ?> <a href="<?php echo e(Route::has('front.pages.show') ? route('front.pages.show', ['page' => $page]) : ''); ?>" target="_blank"><i class="feather icon-external-link ml-1"></i></a>
                                                        </div>
                                                    </td>
                                                    <td class="d-flex">
                                                        <?php if(Route::has('front.pages.show')): ?>
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                    <button class="btn btn-success" type="button">
                                                                        <i class="d-flex justify-content-center flex-column feather icon-file cursor-pointer copy_btn"></i>
                                                                    </button>
                                                                </div>
                                                                <input onClick="this.select();" class="ltr page_link form-control" type="text" value="<?php echo e($page->link()); ?>" readonly>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <?php if($page->published): ?>
                                                            <div class="badge badge-pill badge-success badge-md">منتشر شده</div>
                                                        <?php else: ?>
                                                            <div class="badge badge-pill badge-danger badge-md">پیش نویس</div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages.update')): ?>
                                                            <a href="<?php echo e(route('admin.pages.edit', ['page' => $page])); ?>" class="btn btn-success mr-1 waves-effect waves-light">ویرایش</a>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages.delete')): ?>
                                                            <button type="button" data-page="<?php echo e($page->slug); ?>" data-id="<?php echo e($page->id); ?>" class="btn btn-danger mr-1 waves-effect waves-light btn-delete"  data-toggle="modal" data-target="#delete-modal">حذف</button>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </section>

                <?php else: ?>
                    <section class="card">
                        <div class="card-header">
                            <h4 class="card-title">لیست صفحات</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="card-text">
                                    <p>چیزی برای نمایش وجود ندارد!</p>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php endif; ?>
                <?php echo e($pages->links()); ?>


            </div>
        </div>
    </div>

    
    <div class="modal fade text-left" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel19" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel19">آیا مطمئن هستید؟</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    با حذف صفحه دیگر قادر به بازیابی آن نخواهید بود
                </div>
                <div class="modal-footer">
                    <form action="#" id="page-delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="button" class="btn btn-success waves-effect waves-light" data-dismiss="modal">خیر</button>
                        <button type="submit" class="btn btn-danger waves-effect waves-light">بله حذف شود</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('back/assets/js/pages/pages/index.js')); ?>?v=2"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/pages/index.blade.php ENDPATH**/ ?>