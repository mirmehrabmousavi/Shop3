<div class="page dt-sl dt-sn pt-3">
    <p>چیزی برای نمایش وجود ندارد</p>
</div><?php /**PATH D:\Installed\www\LaravelShop\themes\DefaultTheme\src/resources/views/partials/empty.blade.php ENDPATH**/ ?>