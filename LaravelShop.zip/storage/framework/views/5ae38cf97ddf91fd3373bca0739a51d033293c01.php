<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb no-border">
                                    <li class="breadcrumb-item">مدیریت
                                    </li>
                                    <li class="breadcrumb-item">تنظیمات
                                    </li>
                                    <li class="breadcrumb-item active">تنظیمات قالب
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <?php if(config('front.settings.fields')): ?>
                    <section class="users-edit">
                        <div class="card">
                            <div id="main-card" class="card-content">
                                <div class="card-header">
                                    <h4 class="card-title">تنظیمات قالب</h4>
                                </div>
                                <div class="card-body">

                                    <div class="tab-content">

                                        <form id="theme-settings-form" action="<?php echo e(route('admin.themes.settings')); ?>" method="POST">
                                            <div class="row">

                                                <?php $__currentLoopData = config('front.settings.fields'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php switch($setting['input-type']):

                                                        case ('select'): ?>
                                                            <?php echo $__env->make('back.themes.partials.select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php break; ?>

                                                        

                                                    <?php endswitch; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>

                                            <div class="col-12 d-flex flex-sm-row flex-column justify-content-end mt-1">
                                                <button type="submit" class="btn btn-primary glow">ذخیره تغییرات</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php else: ?>
                    <section class="card">
                        <div class="card-header">
                            <h4 class="card-title">تنظیمات قالب</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="card-text">
                                    <p>چیزی برای نمایش وجود ندارد!</p>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.partials.plugins', ['plugins' => ['jquery.validate', 'ckeditor']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('back/assets/js/pages/themes/settings.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\LaravelShop\resources\views/back/themes/settings.blade.php ENDPATH**/ ?>